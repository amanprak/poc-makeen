Steps to run this project:

1. Run `npm i --save` command(nodemon might be required globally)
2. Setup Up env file for database settings and starting global manager email.
3. Run `npm run initial` to initial globalManager Role and admin user
4. Run `npm start` command
5. To Access API open http://127.0.0.1:3000/api-docs/ to see swagger documnetaion